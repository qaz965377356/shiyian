package com.shiyian;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShiyianApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShiyianApplication.class, args);
    }
}
