package com.shiyian.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shiyian.entity.Food;
import org.springframework.stereotype.Component;

@Component
public interface FoodMapper extends BaseMapper<Food> {
}
